﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Scriptyca_Test {
    public partial class LogIn : Form
    {
        MySqlConnection connection = new MySqlConnection("server=localhost;port=3308;userid=adminDB;password=db_userAdmin;database=keqing21_users;");
        public LogIn()
        {
            InitializeComponent();
        }

        public void LogIn_Load() {
            MySqlConnection connection = new MySqlConnection("server=localhost;port=3308;userid=adminDB;password=db_userAdmin;database=keqing21_users;");
            connection.Open();
        }

        
        private void LogIn_Click(object sender, EventArgs e)
        {
            
        }
       

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        public void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        public void logInEventTrigger_Click(object sender, EventArgs e)
        {
            string connString = "server=localhost;port=3308;userid=adminDB;password=db_userAdmin;database=keqing21_users;";
            MySqlDataAdapter mSda = new MySqlDataAdapter("SELECT COUNT(*) FROM users_data WHERE username='" + username.Text + "' AND password='" + password.Text + "'", connString);
            string Query = "SELECT * FROM users_data WHERE username='" + username.Text + "'";

            DataTable dt = new DataTable(); //this is creating a virtual table  
            mSda.Fill(dt);
            
            
            if (dt.Rows[0][0].ToString() == "1")
            {
                /* I have made a new page called home page. If the user is successfully authenticated then the form will be moved to the next form */
                MessageBox.Show("Logged In Successfully!");

                this.Hide();
                mainWindow mnWin = new mainWindow();
               
                
                MySqlConnection MyConn = new MySqlConnection(connString);
                MySqlCommand MyCommand = new MySqlCommand(Query, MyConn);
                MyConn.Open();
                MySqlDataReader rdr = MyCommand.ExecuteReader(); rdr.Read();
                mnWin.userLabel.Text = rdr.GetString(4) + " " + rdr.GetString(3);
                mnWin.acctUser_lbl.Text = rdr.GetString(1);
                mnWin.acctPsd_lbl.Text = rdr.GetString(2);
                mnWin.acctEmail_lbl.Text = rdr.GetString(3);
                mnWin.acctFname_lbl.Text = rdr.GetString(4);

                mnWin.Show();
                connection.Close();
            }
            else
                MessageBox.Show("Invalid username or password");
        }

        private void signUpEventTrigger_Click(object sender, EventArgs e)
        {
            SignUpRegForm signUp = new SignUpRegForm();
            signUp.Show();
            this.Hide();
        }

        private void dbTesterOnClick_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                if (connection.State == ConnectionState.Open)
                {
                    string message = "Connected";
                    string title = "Details";
                    MessageBox.Show(message, title);
                    connection.Close();
                }
                else
                {
                    string message = "Not Connected";
                    string title = "Details";
                    MessageBox.Show(message, title);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void LogIn_Load(object sender, EventArgs e)
        {

        }

        private void closeEventOnClick_Click(object sender, EventArgs e)
        {
            this.Close();
            connection.Close();
        }
    }   
}
