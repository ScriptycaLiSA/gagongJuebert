﻿namespace Scriptyca_Test
{
    partial class SignUpRegForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SignUpRegForm));
            this.closeEventOnClick = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.fnameDataText = new System.Windows.Forms.PlaceholderTextBox();
            this.lnameDataText = new System.Windows.Forms.PlaceholderTextBox();
            this.emailDataText = new System.Windows.Forms.PlaceholderTextBox();
            this.addrDataText = new System.Windows.Forms.PlaceholderTextBox();
            this.userDataTextID = new System.Windows.Forms.PlaceholderTextBox();
            this.passwordDataText = new System.Windows.Forms.PlaceholderTextBox();
            this.tandcAgreeCheck = new System.Windows.Forms.CheckBox();
            this.registerEventTrigger = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // closeEventOnClick
            // 
            this.closeEventOnClick.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.closeEventOnClick.ForeColor = System.Drawing.Color.White;
            this.closeEventOnClick.Location = new System.Drawing.Point(698, 7);
            this.closeEventOnClick.Name = "closeEventOnClick";
            this.closeEventOnClick.Size = new System.Drawing.Size(24, 23);
            this.closeEventOnClick.TabIndex = 28;
            this.closeEventOnClick.Text = "X";
            this.closeEventOnClick.UseVisualStyleBackColor = false;
            this.closeEventOnClick.Click += new System.EventHandler(this.closeEventOnClick_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 380);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(166, 13);
            this.label3.TabIndex = 29;
            this.label3.Text = "Copyright © 2020 by Scriptyca-JP";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(362, 267);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 16);
            this.label8.TabIndex = 47;
            this.label8.Text = "PASSWORD";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Goudy Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(362, 232);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 16);
            this.label9.TabIndex = 46;
            this.label9.Text = "USERNAME";
            // 
            // fnameDataText
            // 
            this.fnameDataText.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fnameDataText.Location = new System.Drawing.Point(133, 183);
            this.fnameDataText.Name = "fnameDataText";
            this.fnameDataText.PlaceholderText = "ENTER FIRST NAME";
            this.fnameDataText.Size = new System.Drawing.Size(200, 29);
            this.fnameDataText.TabIndex = 48;
            this.fnameDataText.TextChanged += new System.EventHandler(this.fnameDataText_TextChanged);
            // 
            // lnameDataText
            // 
            this.lnameDataText.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnameDataText.Location = new System.Drawing.Point(133, 215);
            this.lnameDataText.Name = "lnameDataText";
            this.lnameDataText.PlaceholderText = "ENTER LAST NAME";
            this.lnameDataText.Size = new System.Drawing.Size(200, 29);
            this.lnameDataText.TabIndex = 49;
            // 
            // emailDataText
            // 
            this.emailDataText.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailDataText.Location = new System.Drawing.Point(133, 247);
            this.emailDataText.Name = "emailDataText";
            this.emailDataText.PlaceholderText = "ENTER EMAIL HERE";
            this.emailDataText.Size = new System.Drawing.Size(200, 29);
            this.emailDataText.TabIndex = 50;
            // 
            // addrDataText
            // 
            this.addrDataText.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addrDataText.Location = new System.Drawing.Point(133, 279);
            this.addrDataText.Name = "addrDataText";
            this.addrDataText.PlaceholderText = "ENTER ADDRESS HERE";
            this.addrDataText.Size = new System.Drawing.Size(200, 29);
            this.addrDataText.TabIndex = 51;
            // 
            // userDataTextID
            // 
            this.userDataTextID.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userDataTextID.Location = new System.Drawing.Point(448, 226);
            this.userDataTextID.Name = "userDataTextID";
            this.userDataTextID.PlaceholderText = "ENTER USERNAME HERE";
            this.userDataTextID.Size = new System.Drawing.Size(220, 29);
            this.userDataTextID.TabIndex = 52;
            // 
            // passwordDataText
            // 
            this.passwordDataText.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordDataText.Location = new System.Drawing.Point(448, 258);
            this.passwordDataText.Name = "passwordDataText";
            this.passwordDataText.PasswordChar = '*';
            this.passwordDataText.PlaceholderText = "";
            this.passwordDataText.Size = new System.Drawing.Size(220, 29);
            this.passwordDataText.TabIndex = 53;
            // 
            // tandcAgreeCheck
            // 
            this.tandcAgreeCheck.AutoSize = true;
            this.tandcAgreeCheck.Location = new System.Drawing.Point(480, 293);
            this.tandcAgreeCheck.Name = "tandcAgreeCheck";
            this.tandcAgreeCheck.Size = new System.Drawing.Size(151, 17);
            this.tandcAgreeCheck.TabIndex = 54;
            this.tandcAgreeCheck.Text = "I agree that I follow TandC";
            this.tandcAgreeCheck.UseVisualStyleBackColor = true;
            // 
            // registerEventTrigger
            // 
            this.registerEventTrigger.Font = new System.Drawing.Font("Bell MT", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.registerEventTrigger.Location = new System.Drawing.Point(489, 316);
            this.registerEventTrigger.Name = "registerEventTrigger";
            this.registerEventTrigger.Size = new System.Drawing.Size(121, 43);
            this.registerEventTrigger.TabIndex = 55;
            this.registerEventTrigger.Text = "REGISTER";
            this.registerEventTrigger.UseVisualStyleBackColor = true;
            this.registerEventTrigger.Click += new System.EventHandler(this.registerEventTrigger_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(205, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(353, 117);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 56;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bell MT", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(312, 132);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 31);
            this.label1.TabIndex = 57;
            this.label1.Text = "SIGN-UP";
            // 
            // SignUpRegForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(729, 402);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.registerEventTrigger);
            this.Controls.Add(this.tandcAgreeCheck);
            this.Controls.Add(this.passwordDataText);
            this.Controls.Add(this.userDataTextID);
            this.Controls.Add(this.addrDataText);
            this.Controls.Add(this.emailDataText);
            this.Controls.Add(this.lnameDataText);
            this.Controls.Add(this.fnameDataText);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.closeEventOnClick);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SignUpRegForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SignUpRegForm";
            this.Load += new System.EventHandler(this.SignUpRegForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button closeEventOnClick;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PlaceholderTextBox fnameDataText;
        private System.Windows.Forms.PlaceholderTextBox lnameDataText;
        private System.Windows.Forms.PlaceholderTextBox emailDataText;
        private System.Windows.Forms.PlaceholderTextBox addrDataText;
        private System.Windows.Forms.PlaceholderTextBox userDataTextID;
        private System.Windows.Forms.PlaceholderTextBox passwordDataText;
        private System.Windows.Forms.CheckBox tandcAgreeCheck;
        private System.Windows.Forms.Button registerEventTrigger;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
    }
}