﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Scriptyca_Test
{
    public partial class SignUpRegForm : Form
    {
        MySqlConnection connection = new MySqlConnection("server=johnny.heliohost.org;port=3306;userid=keqing21_adminDB;password=db_userAdmin;database=keqing21_users;");
        public SignUpRegForm()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void SignUpRegForm_Load(object sender, EventArgs e)
        {

        }

        private void closeEventOnClick_Click(object sender, EventArgs e)
        {
            LogIn logIn = new LogIn();
            this.Close();
            logIn.Show();
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void fnameDataText_TextChanged(object sender, EventArgs e)
        {

        }

        private void registerEventTrigger_Click(object sender, EventArgs e)
        {
            try
            {
                //This is the connection string which stores the database credentialsto connect to the MySQL server
                string MyConnection = "server=localhost;port=3308;userid=adminDB;password=db_userAdmin;database=keqing21_users;";
                //This is my insert query which takes user input from the user throughwindows forms
                string Query = "insert into users_data(username,password,fname,lname,email,address) values('" + this.userDataTextID.Text + "','" + this.passwordDataText.Text + "','" + this.fnameDataText.Text + "','" + this.lnameDataText.Text + "','" + this.emailDataText.Text + "','" + this.addrDataText.Text + "');";
                //This is the MySQL connection in which the connection string is passed
                MySqlConnection MyConn = new MySqlConnection(MyConnection);
                //This is command class which will handle the query and connection object.
                MySqlCommand MyCommand = new MySqlCommand(Query, MyConn);
                MySqlDataReader MyReader;
                MyConn.Open();
                //the query will be executed and data saved into the database.
                MyReader = MyCommand.ExecuteReader();
                MessageBox.Show("Your Credentials have" + Environment.NewLine + "been saved!");
               
                //return to login page
                LogIn lg = new LogIn();
                this.Hide();
                lg.Show();
                MyConn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
