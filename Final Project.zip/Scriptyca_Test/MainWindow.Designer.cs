﻿namespace Scriptyca_Test
{
    partial class mainWindow
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mainWindow));
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label14 = new System.Windows.Forms.Label();
            this.downloadBut = new System.Windows.Forms.Button();
            this.downloadSelect = new System.Windows.Forms.ComboBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label10 = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.button2 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.selector = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.selectMode = new System.Windows.Forms.ComboBox();
            this.button3 = new System.Windows.Forms.Button();
            this.homeTab = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.userLabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.pageDynamicMain = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.acctFname_lbl = new System.Windows.Forms.Label();
            this.acctEmail_lbl = new System.Windows.Forms.Label();
            this.acctPsd_lbl = new System.Windows.Forms.Label();
            this.acctUser_lbl = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.tabPage4.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.homeTab.SuspendLayout();
            this.pageDynamicMain.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 424);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(166, 13);
            this.label3.TabIndex = 19;
            this.label3.Text = "Copyright © 2020 by Scriptyca-JP";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.label14);
            this.tabPage4.Controls.Add(this.downloadBut);
            this.tabPage4.Controls.Add(this.downloadSelect);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(730, 387);
            this.tabPage4.TabIndex = 4;
            this.tabPage4.Text = "DOWLOADABLES";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Bell MT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(125, 62);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(488, 38);
            this.label14.TabIndex = 28;
            this.label14.Text = "Download a material of your choice!";
            // 
            // downloadBut
            // 
            this.downloadBut.Font = new System.Drawing.Font("Bell MT", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.downloadBut.Location = new System.Drawing.Point(297, 201);
            this.downloadBut.Name = "downloadBut";
            this.downloadBut.Size = new System.Drawing.Size(121, 43);
            this.downloadBut.TabIndex = 27;
            this.downloadBut.Text = "DOWNLOAD NOW!";
            this.downloadBut.UseVisualStyleBackColor = true;
            this.downloadBut.Click += new System.EventHandler(this.button6_Click);
            // 
            // downloadSelect
            // 
            this.downloadSelect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.downloadSelect.FormattingEnabled = true;
            this.downloadSelect.Items.AddRange(new object[] {
            "HIRAGANA",
            "KATAKANA",
            "KANJI"});
            this.downloadSelect.Location = new System.Drawing.Point(229, 130);
            this.downloadSelect.Name = "downloadSelect";
            this.downloadSelect.Size = new System.Drawing.Size(259, 21);
            this.downloadSelect.TabIndex = 20;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.progressBar1);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(730, 387);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "PROGRESS TRACKER";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Bell MT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(110, 58);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(503, 38);
            this.label10.TabIndex = 26;
            this.label10.Text = "Your Mastery in Japanese Language:";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(169, 156);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(392, 23);
            this.progressBar1.TabIndex = 19;
            this.progressBar1.Value = 25;
            this.progressBar1.Click += new System.EventHandler(this.progressBar1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(700, 6);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(24, 23);
            this.button2.TabIndex = 18;
            this.button2.Text = "X";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.selector);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.selectMode);
            this.tabPage2.Controls.Add(this.button3);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(730, 387);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "LEARN JAPANESE";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // selector
            // 
            this.selector.Font = new System.Drawing.Font("Bell MT", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selector.Location = new System.Drawing.Point(296, 207);
            this.selector.Name = "selector";
            this.selector.Size = new System.Drawing.Size(121, 43);
            this.selector.TabIndex = 26;
            this.selector.Text = "SELECT";
            this.selector.UseVisualStyleBackColor = true;
            this.selector.Click += new System.EventHandler(this.logInEventTrigger_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Bell MT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(30, 76);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(667, 38);
            this.label8.TabIndex = 25;
            this.label8.Text = "Choose your preferred Japanese Writing to learn!";
            // 
            // selectMode
            // 
            this.selectMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.selectMode.FormattingEnabled = true;
            this.selectMode.Items.AddRange(new object[] {
            "HIRAGANA",
            "KATAKANA",
            "KANJI"});
            this.selectMode.Location = new System.Drawing.Point(233, 146);
            this.selectMode.Name = "selectMode";
            this.selectMode.Size = new System.Drawing.Size(259, 21);
            this.selectMode.TabIndex = 19;
            this.selectMode.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(700, 6);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(24, 23);
            this.button3.TabIndex = 18;
            this.button3.Text = "X";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // homeTab
            // 
            this.homeTab.Controls.Add(this.label5);
            this.homeTab.Controls.Add(this.label7);
            this.homeTab.Controls.Add(this.label6);
            this.homeTab.Controls.Add(this.userLabel);
            this.homeTab.Controls.Add(this.label4);
            this.homeTab.Controls.Add(this.label2);
            this.homeTab.Controls.Add(this.label1);
            this.homeTab.Controls.Add(this.button4);
            this.homeTab.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homeTab.Location = new System.Drawing.Point(4, 22);
            this.homeTab.Name = "homeTab";
            this.homeTab.Padding = new System.Windows.Forms.Padding(3);
            this.homeTab.Size = new System.Drawing.Size(730, 387);
            this.homeTab.TabIndex = 0;
            this.homeTab.Text = "HOME";
            this.homeTab.UseVisualStyleBackColor = true;
            this.homeTab.Click += new System.EventHandler(this.homeTab_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bell MT", 15F);
            this.label5.Location = new System.Drawing.Point(298, 74);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 23);
            this.label5.TabIndex = 26;
            this.label5.Text = "ACCOUNT:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Bell MT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(242, 231);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(229, 18);
            this.label7.TabIndex = 25;
            this.label7.Text = "Go to Learn Japanese to start >>";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bell MT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(233, 164);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(238, 38);
            this.label6.TabIndex = 24;
            this.label6.Text = "Happy Learning!";
            // 
            // userLabel
            // 
            this.userLabel.AutoSize = true;
            this.userLabel.Font = new System.Drawing.Font("Bell MT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userLabel.Location = new System.Drawing.Point(222, 116);
            this.userLabel.Name = "userLabel";
            this.userLabel.Size = new System.Drawing.Size(219, 38);
            this.userLabel.TabIndex = 23;
            this.userLabel.Text = "{{ username }}";
            this.userLabel.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bell MT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(260, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(193, 38);
            this.label4.TabIndex = 22;
            this.label4.Text = "WELCOME,";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bell MT", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(238, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 42);
            this.label2.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bell MT", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(254, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 42);
            this.label1.TabIndex = 20;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(701, 3);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(26, 28);
            this.button4.TabIndex = 19;
            this.button4.Text = "X";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // pageDynamicMain
            // 
            this.pageDynamicMain.Controls.Add(this.homeTab);
            this.pageDynamicMain.Controls.Add(this.tabPage2);
            this.pageDynamicMain.Controls.Add(this.tabPage1);
            this.pageDynamicMain.Controls.Add(this.tabPage4);
            this.pageDynamicMain.Controls.Add(this.tabPage3);
            this.pageDynamicMain.Controls.Add(this.tabPage5);
            this.pageDynamicMain.Location = new System.Drawing.Point(4, 4);
            this.pageDynamicMain.Name = "pageDynamicMain";
            this.pageDynamicMain.SelectedIndex = 0;
            this.pageDynamicMain.Size = new System.Drawing.Size(738, 413);
            this.pageDynamicMain.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.pictureBox1);
            this.tabPage3.Controls.Add(this.button5);
            this.tabPage3.Controls.Add(this.button1);
            this.tabPage3.Controls.Add(this.label18);
            this.tabPage3.Controls.Add(this.acctFname_lbl);
            this.tabPage3.Controls.Add(this.acctEmail_lbl);
            this.tabPage3.Controls.Add(this.acctPsd_lbl);
            this.tabPage3.Controls.Add(this.acctUser_lbl);
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(730, 387);
            this.tabPage3.TabIndex = 5;
            this.tabPage3.Text = "PROFILE AND ACCOUNT SETTINGS";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(509, 81);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(140, 140);
            this.pictureBox1.TabIndex = 40;
            this.pictureBox1.TabStop = false;
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Bell MT", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(403, 269);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(121, 43);
            this.button5.TabIndex = 35;
            this.button5.Text = "DELETE ACCOUNT";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Bell MT", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(191, 269);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(121, 43);
            this.button1.TabIndex = 34;
            this.button1.Text = "LOGOUT";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Bell MT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(184, 27);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(322, 38);
            this.label18.TabIndex = 33;
            this.label18.Text = "ACCOUNT DETAILS";
            // 
            // acctFname_lbl
            // 
            this.acctFname_lbl.AutoSize = true;
            this.acctFname_lbl.Font = new System.Drawing.Font("Bell MT", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acctFname_lbl.Location = new System.Drawing.Point(219, 194);
            this.acctFname_lbl.Name = "acctFname_lbl";
            this.acctFname_lbl.Size = new System.Drawing.Size(132, 27);
            this.acctFname_lbl.TabIndex = 32;
            this.acctFname_lbl.Text = "{{ data% }}";
            // 
            // acctEmail_lbl
            // 
            this.acctEmail_lbl.AutoSize = true;
            this.acctEmail_lbl.Font = new System.Drawing.Font("Bell MT", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acctEmail_lbl.Location = new System.Drawing.Point(219, 158);
            this.acctEmail_lbl.Name = "acctEmail_lbl";
            this.acctEmail_lbl.Size = new System.Drawing.Size(132, 27);
            this.acctEmail_lbl.TabIndex = 31;
            this.acctEmail_lbl.Text = "{{ data% }}";
            // 
            // acctPsd_lbl
            // 
            this.acctPsd_lbl.AutoSize = true;
            this.acctPsd_lbl.Font = new System.Drawing.Font("Bell MT", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acctPsd_lbl.Location = new System.Drawing.Point(219, 121);
            this.acctPsd_lbl.Name = "acctPsd_lbl";
            this.acctPsd_lbl.Size = new System.Drawing.Size(132, 27);
            this.acctPsd_lbl.TabIndex = 30;
            this.acctPsd_lbl.Text = "{{ data% }}";
            // 
            // acctUser_lbl
            // 
            this.acctUser_lbl.AutoSize = true;
            this.acctUser_lbl.Font = new System.Drawing.Font("Bell MT", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acctUser_lbl.Location = new System.Drawing.Point(219, 83);
            this.acctUser_lbl.Name = "acctUser_lbl";
            this.acctUser_lbl.Size = new System.Drawing.Size(132, 27);
            this.acctUser_lbl.TabIndex = 29;
            this.acctUser_lbl.Text = "{{ data% }}";
            this.acctUser_lbl.Click += new System.EventHandler(this.label14_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Bell MT", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(27, 194);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(166, 27);
            this.label13.TabIndex = 28;
            this.label13.Text = "FIRST NAME:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Bell MT", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(27, 158);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(96, 27);
            this.label12.TabIndex = 27;
            this.label12.Text = "EMAIL:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Bell MT", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(27, 121);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(151, 27);
            this.label11.TabIndex = 26;
            this.label11.Text = "PASSWORD:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Bell MT", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(27, 83);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(153, 27);
            this.label9.TabIndex = 25;
            this.label9.Text = "USERNAME:";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.label20);
            this.tabPage5.Controls.Add(this.label19);
            this.tabPage5.Controls.Add(this.pictureBox2);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(730, 387);
            this.tabPage5.TabIndex = 6;
            this.tabPage5.Text = "ABOUT";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(284, 278);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(166, 13);
            this.label20.TabIndex = 20;
            this.label20.Text = "Copyright © 2020 by Scriptyca-JP";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Bell MT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(272, 260);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(185, 18);
            this.label19.TabIndex = 26;
            this.label19.Text = "v.1.0.0-alpha-dmmmsu_rel";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(50, 6);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(615, 233);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            this.backgroundWorker1.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.backgroundWorker1_ProgressChanged);
            // 
            // mainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(745, 441);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pageDynamicMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "mainWindow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.homeTab.ResumeLayout(false);
            this.homeTab.PerformLayout();
            this.pageDynamicMain.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox selectMode;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button selector;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.PictureBox pictureBox2;
        public System.Windows.Forms.TabPage homeTab;
        public System.Windows.Forms.Label userLabel;
        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.TabControl pageDynamicMain;
        public System.Windows.Forms.TabPage tabPage3;
        public System.Windows.Forms.Label acctUser_lbl;
        public System.Windows.Forms.Label acctFname_lbl;
        public System.Windows.Forms.Label acctEmail_lbl;
        public System.Windows.Forms.Label acctPsd_lbl;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button downloadBut;
        private System.Windows.Forms.ComboBox downloadSelect;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
    }
}
