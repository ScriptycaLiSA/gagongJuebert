﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Threading;

namespace Scriptyca_Test
{
    public partial class mainWindow : Form
    {
        MySqlConnection connection = new MySqlConnection("server=localhost;port=3306;userid=adminDB;password=db_userAdmin;database=healthdecsystem");
        public mainWindow()
        {
            InitializeComponent();
        }
        public void DynamicDataPage_Load(object sender, EventArgs e) {
            BindData();
            //Well, today i am testing a new keyboard
        }

        private void BindData() {
            ComboBox cbSelect = new ComboBox();
            MySqlCommand cmd = new MySqlCommand("server=localhost;port=3306;userid=adminDB;password=db_userAdmin;database=healthdecsystem", connection);
            connection.Open();
            MySqlDataReader reader = cmd.ExecuteReader();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            LogIn li_ret = new LogIn();
            this.Hide();
            li_ret.Show();
            connection.Close();
        }

        private void resourcesBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void bindingSource1_CurrentChanged(object sender, EventArgs e)
        {

        }

        public void label14_Click(object sender, EventArgs e)
        {

        }

        private void homeTab_Click(object sender, EventArgs e)
        {

        }

        public void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You have successfully logged out!");
            LogIn fm1 = new LogIn();
            this.Hide();
            fm1.Show();
            this.Close();
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            LogIn fr1 = new LogIn();
            try
            {
                //This is the connection string which stores the database credentials to connect to the MySQL server
                string connString = "server=localhost;port=3308;userid=adminDB;password=db_userAdmin;database=keqing21_users;";
                //This is my insert query in which i am taking input from the user through windows forms
                string Query = "delete from users_data where username='" + acctUser_lbl.Text + "'";
                //This is the MySQL connection in which the connection string is passed
                MySqlConnection MyConn = new MySqlConnection(connString);
                //This is command class which will handle the query and connection object.
                MySqlCommand MyCommand = new MySqlCommand(Query, MyConn);
                MySqlDataReader MyReader;
                MyConn.Open();
                MyReader = MyCommand.ExecuteReader(); // Here our query will be executed and data saved into the database.
                MessageBox.Show("Record Deleted");
                this.Hide();
                MyConn.Close();
                fr1.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }
        
        private void logInEventTrigger_Click(object sender, EventArgs e)
        {
            string cmb = selectMode.Text;
            string hirA = "HIRAGANA"; string katA = "KATAKANA"; string kanJ = "KANJI";
            if (cmb == hirA)
            {
                string url1 = "https://realkana.com/hiragana/";
                System.Diagnostics.Process.Start(url1);
            }
            else if (cmb == katA)
            {
                string url2 = "https://realkana.com/katakana/";
                System.Diagnostics.Process.Start(url2);
            }
            else if (cmb == kanJ)
            {
                string url2 = "https://kanjialive.com/214-traditional-kanji-radicals/";
                System.Diagnostics.Process.Start(url2);
            }
            else {
                MessageBox.Show("You need to select a Japanese" + Environment.NewLine + "writing first!");            
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            string cmb = downloadSelect.Text;
            string hirA = "HIRAGANA"; string katA = "KATAKANA"; string kanJ = "KANJI";
            if (cmb == hirA)
            {
                string url1 = "https://www.szfki.hu/~akiss/others/hiragana_table.pdf";
                System.Diagnostics.Process.Start(url1);
            }
            else if (cmb == katA)
            {
                string url2 = "http://japanese-lesson.com/characters/katakana/pdf/katakana_table.pdf";
                System.Diagnostics.Process.Start(url2);
            }
            else if (cmb == kanJ)
            {
                string url2 = "https://www.uni-passau.de/fileadmin/dokumente/hsg/nippon/Skripte/kanjibookjlptn5.pdf";
                System.Diagnostics.Process.Start(url2);
            }
            else
            {
                MessageBox.Show("Select a category" + Environment.NewLine + "to download!");
            }
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            for (int i = 1; i <= 100; i++)
            {
                // Wait 50 milliseconds.  
                Thread.Sleep(50);
                // Report progress.  
                backgroundWorker1.ReportProgress(i);
            }
        }

        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            // Change the value of the ProgressBar  
            progressBar1.Value = e.ProgressPercentage;
            // Set the text.  
            this.Text = "Progress: " + e.ProgressPercentage.ToString() + "%";
        }
        private void Form2_Load(object sender, System.EventArgs e)
        {
            backgroundWorker1.WorkerReportsProgress = true;
            backgroundWorker1.RunWorkerAsync();
        }
    }
}
